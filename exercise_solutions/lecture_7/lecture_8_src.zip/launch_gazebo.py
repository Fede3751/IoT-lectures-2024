from launch import LaunchDescription
from launch_ros.actions import Node

from launch_ros.substitutions import FindPackageShare
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from random import randint

WORLD_FILE = "drone_world.sdf"

def generate_launch_description():

    launch_nodes = [
    IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
        PathJoinSubstitution([
            FindPackageShare('ros_gz_sim'),
            'launch/'
            'gz_sim.launch.py',
        ])
        ]),
        launch_arguments={
        'gz_args' : "./"+WORLD_FILE
        }.items()
    ),
    ]

    for i in range(3):


        launch_nodes.extend([
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=[
                f"/X3_{i}/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist"
                ],
                name='cmd_vel_bridge'
            ),
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=[
                f"/X3_{i}/odometry@nav_msgs/msg/Odometry@ignition.msgs.Odometry"
                ],
                name='odometry_bridge'
            ),
            Node(
                package='exercise8_src',
                executable='drone_controller',
                name='drone_controller',
                namespace=f'X3_{i}'
            )
        ])


    return LaunchDescription(launch_nodes)

